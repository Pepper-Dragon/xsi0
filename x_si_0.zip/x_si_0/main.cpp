#include <iostream>
#include <stdlib.h>
using namespace std;

int v[100][100],s=0;
int a[8];

void display()
{for(int j=0;j<3;j++)
{for(int i=0;i<3;i++)
{
cout<<char(v[j][i])<<" ";
}
cout<<endl;
}}

void win(int& ye)
{int s=0;
while(s<3)
{if(v[s][0]==88 && v[s][1]==88 && v[s][2]==88)
{cout<<"AI CASTIGAT!!!";
ye=1;
break;}
if(v[0][s]==88 && v[1][s]==88 && v[2][s]==88)
{cout<<"AI CASTIGAT!!!";
ye=1;
break;}
if(v[0][0]==88 && v[1][1]==88 && v[2][2]==88)
{cout<<"AI CASTIGAT!!!";
ye=1;
break;}
if(v[2][0]==88 && v[1][1]==88 && v[0][2]==88)
{cout<<"AI CASTIGAT!!!";
ye=1;
break;}
ye=0;
s++;
}
}

void lose(int& l)
{int s=0;
while(s<3)
{if(v[s][0]==79 && v[s][1]==79 && v[s][2]==79)
{cout<<"AI PIERDUT:/";
l=1;
break;}
if(v[0][s]==79 && v[1][s]==79 && v[2][s]==79)
{cout<<"AI PIERDUT:/";
l=1;
break;}
if(v[0][0]==79 && v[1][1]==79 && v[2][2]==79)
{cout<<"AI PIERDUT:/";
l=1;
break;}
if(v[2][0]==79 && v[1][1]==79 && v[0][2]==79)
{cout<<"AI PIERDUT:/";
l=1;
break;}
l=0;
s++;
}
}


void bot(){

int maxi=-1000,aux,r,r1;

r= rand() % 2 + 1;
r1=rand() % 3 + 1;

cout<<r;
cout<<endl<<r1<<endl;

if(v[0][0]==88)
{a[0]--;
a[3]--;
a[6]--;}

if(v[0][1]==88)
{a[0]--;
a[4]--;}

if(v[0][2]==88)
{a[0]--;
a[5]--;
a[7]--;}

if(v[1][0]==88)
{a[1]--;
a[4]--;}

if(v[1][1]==88)
{a[1]--;
a[4]--;
a[6]--;
a[7]--;}

if(v[1][2]==88)
{a[1]--;
a[5]--;}

if(v[2][0]==88)
{a[2]--;
a[3]--;
a[7]--;}

if(v[2][1]==88)
{a[2]--;
a[4]--;}

if(v[2][2]==88)
{a[2]--;
a[5]--;
a[6]--;}

if(v[0][0]==79)
{a[0]++;
a[3]++;
a[6]++;}

if(v[0][1]==79)
{a[0]++;
a[4]++;}

if(v[0][2]==79)
{a[0]++;
a[5]++;
a[7]++;}

if(v[1][0]==79)
{a[1]++;
a[3]++;}

if(v[1][1]==79)
{a[1]++;
a[4]++;
a[6]++;
a[7]++;}

if(v[1][2]==79)
{a[1]++;
a[5]++;}

if(v[2][0]==79)
{a[2]++;
a[3]++;
a[7]++;}

if(v[2][1]==79)
{a[2]++;
a[4]++;}

if(v[2][2]==79)
{a[2]++;
a[5]++;
a[6]++;}


for(int i=0;i<8;i++)
{if(maxi<=a[i])
{maxi=a[i];
aux=i;}}

switch(aux){
case 0:

if(v[0][0]!=45 and v[0][1]==45 and v[0][2]==45)
{if(r==1)
{v[0][1]=79;}
else if(r==2)
{v[0][2]=79;}
}
else if(v[0][1]!=45 and v[0][0]==45 and v[0][2]==45)
{if(r==1)
{v[0][0]=79;}
else if(r==2)
{v[0][2]=79;}
}
else if(v[0][2]!=45 and v[0][0]==45 and v[0][1]==45)
{if(r==1)
{v[0][0]=79;}
else if(r==2)
{v[0][1]=79;}
}
else if(v[0][0]!=45 and v[0][1]!=45 and v[0][2]==45)
{v[0][2]=79;}

else if(v[0][0]!=45 and v[0][1]==45 and v[0][2]!=45)
{v[0][1]=79;}

else if(v[0][0]==45 and v[0][1]!=45 and v[0][2]!=45)
{v[0][0]=79;}

else if(v[0][0]==45 and v[0][1]==45 and v[0][2]==45)
{if(r1==1)
{v[0][0]=79;}
else if(r1==2)
{v[0][1]=79;}
else if(r1==3)
{v[0][2]=79;}
}

break;

case 1:

if(v[1][0]!=45 and v[1][1]==45 and v[1][2]==45)
{if(r==1)
{v[1][1]=79;}
else if(r==2)
{v[1][2]=79;}
}
else if(v[1][1]!=45 and v[1][0]==45 and v[1][2]==45)
{if(r==1)
{v[1][0]=79;}
else if(r==2)
{v[1][2]=79;}
}
else if(v[1][2]!=45 and v[1][0]==45 and v[1][1]==45)
{if(r==1)
{v[1][0]=79;}
else if(r==2)
{v[1][1]=79;}
}

else if(v[1][0]!=45 and v[1][1]!=45 and v[1][2]==45)
{v[1][2]=79;}

else if(v[1][0]!=45 and v[1][1]==45 and v[1][2]!=45)
{v[1][1]=79;}

else if(v[1][0]==45 and v[1][1]!=45 and v[1][2]!=45)
{v[1][0]=79;}

else if(v[1][0]==45 and v[1][1]==45 and v[1][2]==45)
{if(r1==1)
{v[1][0]=79;}
else if(r1==2)
{v[1][1]=79;}
else if(r1==3)
{v[1][2]=79;}
}

break;

case 2:

if(v[2][0]!=45 and v[2][1]==45 and v[2][2]==45)
{if(r==1)
{v[2][1]=79;}
else if(r==2)
{v[2][2]=79;}
}
else if(v[2][1]!=45 and v[2][0]==45 and v[2][2]==45)
{if(r==1)
{v[2][0]=79;}
else if(r==2)
{v[2][2]=79;}
}
else if(v[2][2]!=45 and v[2][0]==45 and v[2][1]==45)
{if(r==1)
{v[2][0]=79;}
else if(r==2)
{v[2][1]=79;}
}

else if(v[2][0]!=45 and v[2][1]!=45 and v[2][2]==45)
{v[2][2]=79;}

else if(v[2][0]!=45 and v[2][1]==45 and v[2][2]!=45)
{v[2][1]=79;}

else if(v[2][0]==45 and v[2][1]!=45 and v[2][2]!=45)
{v[2][0]=79;}

else if(v[2][0]==45 and v[2][1]==45 and v[2][2]==45)
{if(r1==1)
{v[2][0]=79;}
else if(r1==2)
{v[2][1]=79;}
else if(r1==3)
{v[2][2]=79;}
}

break;

case 3:

if(v[0][0]!=45 and v[1][0]==45 and v[2][0]==45)
{if(r==1)
{v[1][0]=79;}
else if(r==2)
{v[2][0]=79;}
}
else if(v[1][0]!=45  and v[0][0]==45 and v[2][0]==45)
{if(r==1)
{v[0][0]=79;}
else if(r==2)
{v[2][0]=79;}
}
else if(v[2][0]!=45  and v[0][0]==45 and v[1][0]==45)
{if(r==1)
{v[0][0]=79;}
else if(r==2)
{v[1][0]=79;}
}

else if(v[0][0]!=45 and v[1][0]!=45 and v[2][0]==45)
{v[2][0]=79;}

else if(v[0][0]!=45 and v[1][0]==45 and v[2][0]!=45)
{v[1][0]=79;}

else if(v[0][0]==45 and v[1][0]!=45 and v[2][0]!=45)
{v[0][0]=79;}

else if(v[0][0]==45 and v[1][0]==45 and v[2][0]==45)
{if(r1==1)
{v[0][0]=79;}
else if(r1==2)
{v[1][0]=79;}
else if(r1==3)
{v[2][0]=79;}
}

break;

case 4:

if(v[0][1]!=45  and v[1][1]==45 and v[2][1]==45)
{if(r==1)
{v[1][1]=79;}
else if(r==2)
{v[2][1]=79;}
}
else if(v[1][1]!=45  and v[0][1]==45 and v[2][1]==45)
{if(r==1)
{v[0][1]=79;}
else if(r==2)
{v[2][1]=79;}
}
else if(v[2][1]!=45  and v[0][1]==45 and v[1][1]==45)
{if(r==1)
{v[0][1]=79;}
else if(r==2)
{v[1][1]=79;}
}

else if(v[0][1]!=45 and v[1][1]!=45 and v[2][1]==45)
{v[2][1]=79;}

else if(v[0][1]!=45 and v[1][1]==45 and v[2][1]!=45)
{v[1][1]=79;}

else if(v[0][1]==45 and v[1][1]!=45 and v[2][1]!=45)
{v[0][1]=79;}

else if(v[0][1]==45 and v[1][1]==45 and v[2][1]==45)
{if(r1==1)
{v[0][1]=79;}
else if(r1==2)
{v[1][1]=79;}
else if(r1==3)
{v[2][1]=79;}
}

break;

case 5:

if(v[0][2]!=45  and v[1][2]==45 and v[2][2]==45)
{if(r==1)
{v[1][2]=79;}
else if(r==2)
{v[2][2]=79;}
}
else if(v[1][2]!=45  and v[0][2]==45 and v[2][2]==45)
{if(r==1)
{v[0][2]=79;}
else if(r==2)
{v[2][2]=79;}
}
else if(v[2][2]!=45  and v[0][2]==45 and v[1][2]==45)
{if(r==1)
{v[0][2]=79;}
else if(r==2)
{v[1][2]=79;}
}

else if(v[0][2]!=45 and v[1][2]!=45 and v[2][2]==45)
{v[2][2]=79;}

else if(v[0][2]!=45 and v[1][2]==45 and v[2][2]!=45)
{v[1][2]=79;}

else if(v[0][2]==45 and v[1][2]!=45 and v[2][2]!=45)
{v[0][2]=79;}

else if(v[0][2]==45 and v[1][2]==45 and v[2][2]==45)
{if(r1==1)
{v[0][2]=79;}
else if(r1==2)
{v[1][2]=79;}
else if(r1==3)
{v[2][2]=79;}
}

break;

case 6:

if(v[0][0]!=45  and v[1][1]==45 and v[2][2]==45)
{if(r==1)
{v[1][1]=79;}
else if(r==2)
{v[2][2]=79;}
}
else if(v[1][1]!=45  and v[0][0]==45 and v[2][2]==45)
{if(r==1)
{v[0][0]=79;}
else if(r==2)
{v[2][2]=79;}
}
else if(v[2][2]!=45  and v[0][0]==45 and v[1][1]==45)
{if(r==1)
{v[0][0]=79;}
else if(r==2)
{v[1][1]=79;}
}

else if(v[0][0]!=45 and v[1][1]!=45 and v[2][2]==45)
{v[2][2]=79;}

else if(v[0][0]!=45 and v[1][1]==45 and v[2][2]!=45)
{v[1][1]=79;}

else if(v[0][0]==45 and v[1][1]!=45 and v[2][2]!=45)
{v[0][0]=79;}

else if(v[0][0]!=45 and v[1][1]==45 and v[2][2]==45)
{if(r1==1)
{v[0][0]=79;}
else if(r1==2)
{v[1][1]=79;}
else if(r1==3)
{v[2][2]=79;}
}

break;

case 7:

if(v[2][0]!=45  and v[1][1]==45 and v[0][2]==45)
{if(r==1)
{v[1][1]=79;}
else if(r==2)
{v[0][2]=79;}
}
else if(v[1][1]!=45  and v[2][0]==45 and v[0][2]==45)
{if(r==1)
{v[2][0]=79;}
else if(r==2)
{v[0][2]=79;}
}
else if(v[0][2]!=45  and v[2][0]==45 and v[1][1]==45)
{if(r==1)
{v[2][0]=79;}
else if(r==2)
{v[1][1]=79;}
}

else if(v[2][0]!=45 and v[1][1]!=45 and v[0][2]==45)
{v[0][2]=79;}

else if(v[2][0]!=45 and v[1][1]==45 and v[0][2]!=45)
{v[1][1]=79;}

else if(v[2][0]==45 and v[1][1]!=45 and v[0][2]!=45)
{v[2][0]=79;}

else if(v[2][0]==45 and v[1][1]==45 and v[0][2]==45)
{if(r1==1)
{v[2][0]=79;}
else if(r1==2)
{v[1][1]=79;}
else if(r1==3)
{v[0][2]=79;}
}

break;
}

}



int main(){
int col=0,ran=0,ye=0,t=0,l=0;

for(int j=0;j<3;j++)
{for(int i=0;i<9;i++)
{v[j][i]=45;}
}

for(int i=0;i<8;i++)
{a[i]=0;}


display();

while(t<5)
{if(ye==1)
{break;}
lose(l);
if(l==1)
{break;}
t++;
cout<<"coloana:";
cin>>col;
cout<<endl<<"rand:";
cin>>ran;

v[ran-1][col-1]=88;
bot();s
display();

win(ye);
}




}
